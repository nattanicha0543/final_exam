import React, { useState } from 'react'
import Search from '../component/Search';


const SearchPhotos = () => {
   
    return (
        <>
           <Search />
        </>
    )
}

export default SearchPhotos



